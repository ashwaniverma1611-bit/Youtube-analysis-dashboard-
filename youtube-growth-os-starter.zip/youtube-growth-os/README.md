# YouTube Growth OS

A Next.js starter dashboard for a creator who publishes both Shorts and long-form videos.

## What works in this starter
- Dark responsive creator dashboard
- Google OAuth sign-in configured for YouTube read-only and YouTube Analytics read-only scopes
- Server-side endpoint that retrieves channel stats, recent uploads, video views/likes/comments, and a 28-day daily analytics report
- Content Lab starter ideas, channel review checklist, and monetization milestone explainer
- Preview data is visibly labelled and replaced when live API data loads

## Setup
1. Install Node.js 20+.
2. Create a Google Cloud project and enable **YouTube Data API v3** and **YouTube Analytics API**.
3. Configure the OAuth consent screen. Add your Google account as a test user while the app is in testing.
4. Create an OAuth Client ID of type **Web application**.
5. Add this authorized redirect URI: `http://localhost:3000/api/auth/callback/google`
6. Copy `.env.example` to `.env.local` and fill in the credentials. Generate a strong random `NEXTAUTH_SECRET`.
7. Run:
   ```bash
   npm install
   npm run dev
   ```
8. Open http://localhost:3000 and choose **Connect Google**.

## Important
- The app requests read-only scopes. It cannot upload, edit, delete, or manage videos.
- OAuth secrets and access tokens are handled server-side. Never commit `.env.local`.
- Before public deployment, configure HTTPS, a production OAuth redirect URI, a secure secret, an appropriate consent-screen verification/publishing status, privacy policy, and terms of service.
- The dashboard currently displays recent video metrics and a 28-day analytics report payload. The next development step is to add charts, per-video retention/traffic-source reports, saved channel history, and AI topic scoring using a server-side AI key.
- Subscriber totals can be hidden by some channels; YouTube may return rounded public counts. Analytics API values can have reporting delays.
- Monetization eligibility is not inferred from total channel views. Confirm official progress in YouTube Studio > Earn.
