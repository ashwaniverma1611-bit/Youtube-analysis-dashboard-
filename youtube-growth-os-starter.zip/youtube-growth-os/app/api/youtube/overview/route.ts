import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { getToken } from "next-auth/jwt";
import { google } from "googleapis";
import { headers } from "next/headers";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });

  const h = await headers();
  const token = await getToken({ req: { headers: h } as never, secret: process.env.NEXTAUTH_SECRET });
  const accessToken = token?.access_token as string | undefined;
  if (!accessToken) return NextResponse.json({ error: "No YouTube access token. Sign out and reconnect with Google." }, { status: 401 });

  const oauth2 = new google.auth.OAuth2();
  oauth2.setCredentials({ access_token: accessToken });
  const youtube = google.youtube({ version: "v3", auth: oauth2 });
  const analytics = google.youtubeAnalytics({ version: "v2", auth: oauth2 });

  try {
    const channelRes = await youtube.channels.list({ part: ["snippet", "statistics"], mine: true });
    const channel = channelRes.data.items?.[0];
    if (!channel) return NextResponse.json({ error: "No YouTube channel was found for this Google account." }, { status: 404 });

    const channelId = channel.id!;
    const stats = channel.statistics;
    const today = new Date();
    const endDate = today.toISOString().slice(0, 10);
    const start = new Date(today);
    start.setDate(start.getDate() - 28);
    const startDate = start.toISOString().slice(0, 10);

    let report: Record<string, unknown> = {};
    try {
      const r = await analytics.reports.query({
        ids: `channel==${channelId}`,
        startDate, endDate,
        metrics: "views,estimatedMinutesWatched,averageViewDuration,subscribersGained,subscribersLost",
        dimensions: "day",
        sort: "day"
      });
      report = { rows: r.data.rows ?? [], columnHeaders: r.data.columnHeaders ?? [] };
    } catch {
      report = { rows: [], note: "Analytics report is not available yet. Check channel permissions and API access." };
    }

    const videosRes = await youtube.search.list({
      part: ["snippet"], channelId, type: ["video"], order: "date", maxResults: 10
    });
    const videoIds = (videosRes.data.items ?? []).map(v => v.id?.videoId).filter(Boolean) as string[];
    const videoStats = videoIds.length ? await youtube.videos.list({
      part: ["snippet", "statistics", "contentDetails"], id: videoIds
    }) : { data: { items: [] } };

    return NextResponse.json({
      channel: {
        id: channelId, title: channel.snippet?.title,
        thumbnail: channel.snippet?.thumbnails?.high?.url,
        subscribers: Number(stats?.subscriberCount ?? 0),
        views: Number(stats?.viewCount ?? 0),
        videos: Number(stats?.videoCount ?? 0)
      },
      period: { startDate, endDate },
      analytics: report,
      videos: (videoStats.data.items ?? []).map(v => ({
        id: v.id, title: v.snippet?.title, publishedAt: v.snippet?.publishedAt,
        thumbnail: v.snippet?.thumbnails?.medium?.url,
        views: Number(v.statistics?.viewCount ?? 0),
        likes: Number(v.statistics?.likeCount ?? 0),
        comments: Number(v.statistics?.commentCount ?? 0),
        duration: v.contentDetails?.duration
      }))
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : "YouTube API request failed.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
