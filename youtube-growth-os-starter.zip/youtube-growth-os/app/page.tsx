'use client';
import { useEffect, useMemo, useState } from "react";
import { signIn, signOut } from "next-auth/react";

type Video = {id:string;title:string;publishedAt?:string;thumbnail?:string;views:number;likes:number;comments:number};
type Data = {channel:{title:string;thumbnail?:string;subscribers:number;views:number;videos:number};period:{startDate:string;endDate:string};analytics:{rows?:unknown[][]};videos:Video[]};

const sample: Data = {
 channel:{title:"Your YouTube Channel",subscribers:11,views:18400,videos:24},
 period:{startDate:"Last 28 days",endDate:"Today"},
 analytics:{rows:[]},
 videos:[
  {id:"1",title:"The untold story behind a forgotten historical event",views:2100,likes:94,comments:8},
  {id:"2",title:"3 facts you probably didn't know about Indian history",views:1450,likes:61,comments:5},
  {id:"3",title:"A surprising moment that changed history",views:980,likes:43,comments:3}
 ]
};
const ideas=[
 {tag:"History • Shorts",title:"The 30-second mystery: What really happened?",desc:"Open with a surprising question, reveal two verified facts, then end with a comment-driving question."},
 {tag:"History • Shorts",title:"One decision that changed an entire kingdom",desc:"Use a strong before/after contrast and fast visual storytelling."},
 {tag:"Explainer • Long-form",title:"The complete story behind a misunderstood historical event",desc:"Build a 6–9 minute narrative with chapters, maps and credible sources."}
];
function fmt(n:number){return Intl.NumberFormat("en",{notation:n>9999?"compact":"standard",maximumFractionDigits:1}).format(n)}
export default function Home(){
 const [data,setData]=useState<Data>(sample),[connected,setConnected]=useState(false),[loading,setLoading]=useState(false),[error,setError]=useState(""),[tab,setTab]=useState("Overview");
 async function load(){
  setLoading(true);setError("");
  try{const r=await fetch("/api/youtube/overview");const j=await r.json();if(!r.ok)throw new Error(j.error||"Could not load channel.");setData(j);setConnected(true);}
  catch(e){setError(e instanceof Error?e.message:"Unable to load YouTube data.");}
  finally{setLoading(false);}
 }
 useEffect(()=>{load()},[]);
 const latest=data.videos?.slice(0,5)??[];
 const totalViews=useMemo(()=>latest.reduce((a,v)=>a+v.views,0),[latest]);
 return <main className="shell">
  <header className="top"><div className="brand">YOUTUBE<span>●</span> GROWTH OS</div><div style={{display:"flex",gap:9,alignItems:"center"}}><span className="pill">{connected?"LIVE CHANNEL DATA":"PREVIEW MODE"}</span><button className="btn" onClick={()=>signIn("google")}>Connect Google</button></div></header>
  <div className="hero"><div><div className="eyebrow">Creator command center</div><div className="h1">Grow with clarity. Create with purpose.</div><div className="muted">Your channel performance, content strategy and monetization roadmap.</div></div><button className="btn secondary" onClick={load}>{loading?"Refreshing…":"↻ Refresh data"}</button></div>
  {error&&<div className="notice error">YouTube connection: {error}<br/>Preview figures are shown until your Google channel is connected and authorized.</div>}
  <div className="tabs" style={{marginBottom:18}}>{["Overview","Content Lab","Monetization","Channel Review"].map(t=><button className={tab===t?"active":""} key={t} onClick={()=>setTab(t)}>{t}</button>)}</div>
  {tab==="Overview"&&<>
   <div className="grid">
    <div className="panel"><div className="label">Subscribers</div><div className="metric">{fmt(data.channel.subscribers)}</div><div className="delta">Your channel audience</div></div>
    <div className="panel"><div className="label">Lifetime views</div><div className="metric">{fmt(data.channel.views)}</div><div className="label">Total channel views</div></div>
    <div className="panel"><div className="label">Published videos</div><div className="metric">{fmt(data.channel.videos)}</div><div className="label">Videos on your channel</div></div>
    <div className="panel"><div className="label">Latest 5 video views</div><div className="metric">{fmt(totalViews)}</div><div className="label">Combined views in this list</div></div>
   </div>
   <div className="section">Your channel snapshot</div><div className="two">
    <div className="panel"><div style={{display:"flex",justifyContent:"space-between"}}><b>Recent uploads</b><span className="label">Latest videos</span></div>{latest.map(v=><div className="video" key={v.id}><img className="thumb" src={v.thumbnail||"https://placehold.co/160x90/202a3a/ffffff?text=Video"} /><div style={{flex:1}}><div className="videoTitle">{v.title}</div><div className="small">{fmt(v.views)} views · {fmt(v.likes)} likes · {fmt(v.comments)} comments</div></div></div>)}</div>
    <div className="panel"><b>Growth coach</b><p className="muted" style={{fontSize:13,lineHeight:1.6}}>Focus on repeatable formats rather than chasing random viral topics. Compare each upload against your own channel median, then double down on the topics and openings that hold attention.</p><div className="notice">Next action: publish a consistent series with a recognizable format, and review retention after each upload. Use the Content Lab for fresh ideas.</div></div>
   </div>
  </>}
  {tab==="Content Lab"&&<><div className="section">Topic opportunities</div><div className="notice">Starter ideas are tailored to a history / educational storytelling direction. Once your channel is connected, use your actual top-performing videos to refine these suggestions. Validate facts and trends before publishing.</div><div className="grid" style={{gridTemplateColumns:"repeat(auto-fit,minmax(230px,1fr))",marginTop:14}}>{ideas.map((x,i)=><div className="panel" key={i}><span className="tag">{x.tag}</span><b>{x.title}</b><p className="muted" style={{fontSize:13,lineHeight:1.6}}>{x.desc}</p><button className="btn secondary" onClick={()=>navigator.clipboard?.writeText(x.title)}>Copy topic</button></div>)}</div><div className="section">Shorts structure</div><div className="panel"><b>0–2 sec: Hook</b><p className="muted">A bold question, surprising claim or visual mystery.</p><b>3–18 sec: Payoff</b><p className="muted">Deliver the key story with quick visual changes and no unnecessary setup.</p><b>Final seconds: Conversion</b><p className="muted">Give viewers a reason to follow the series, not a generic “subscribe”.</p></div></>}
  {tab==="Monetization"&&<><div className="section">YouTube Partner Program tracker</div><div className="notice">These are commonly used YPP eligibility thresholds; eligibility and feature availability can vary by country and channel. Check the Earn tab in YouTube Studio for your official status. Shorts-feed watch time does not count toward the 4,000 public watch-hour route.</div><div className="grid" style={{marginTop:14}}><div className="panel"><div className="label">Early YPP access route</div><div className="metric">500 subs</div><div className="label">Plus 3 public uploads in 90 days and either 3,000 public watch hours in 12 months or 3M valid Shorts views in 90 days.</div></div><div className="panel"><div className="label">Ads revenue route</div><div className="metric">1,000 subs</div><div className="label">Plus either 4,000 valid public watch hours in 12 months or 10M valid public Shorts views in 90 days.</div></div></div><div className="section">Subscriber progress (illustrative)</div><div className="panel"><div style={{display:"flex",justifyContent:"space-between"}}><b>{fmt(data.channel.subscribers)} / 1,000 subscribers</b><span className="label">{Math.min(100,data.channel.subscribers/10).toFixed(1)}%</span></div><div className="progress"><i style={{width:`${Math.min(100,data.channel.subscribers/10)}%`}}/></div><div className="small">Subscriber count is live when connected. Watch-hour and Shorts-view eligibility must be checked in YouTube Studio Earn.</div></div></>}
  {tab==="Channel Review"&&<><div className="section">Channel review checklist</div><div className="grid" style={{gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))"}}>{[["Packaging","Make the title and thumbnail communicate one clear curiosity gap."],["Retention","Show the promised payoff early; remove slow introductions."],["Series strategy","Create repeatable topic series so one video naturally leads to another."],["Subscriber conversion","Give viewers a specific reason to return for the next episode."],["Consistency","Choose a sustainable upload schedule and maintain quality."],["Monetization safety","Use original narration, editing and meaningful commentary; avoid reused-content-only uploads."]].map(([a,b])=><div className="panel" key={a}><b>{a}</b><p className="muted" style={{fontSize:13,lineHeight:1.6}}>{b}</p></div>)}</div></>}
  <footer className="small" style={{marginTop:35,paddingBottom:15}}>YouTube Growth OS · Preview data is clearly labelled until Google authorization succeeds. This tool is independent and not affiliated with YouTube.</footer>
 </main>;
}
